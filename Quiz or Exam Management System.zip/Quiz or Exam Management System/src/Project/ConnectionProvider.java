/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Project;
import java.sql.*;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
/**
 *
 * @author Rishi
 */
public class ConnectionProvider {
    public static Connection getCon()
    {
               try{
               
                   Class.forName("com.mysql.jdbc.Driver");
                   Connection con=DriverManager.getConnection("jdbc:mysql://localhost3306/exam","root","srushi3061@$%rishi");
                   return con;
               
               }
                 catch(ClassNotFoundException | SQLException e)
                 {JFrame jf=new JFrame();
                 jf.setAlwaysOnTop(true);
                   JOptionPane.showMessageDialog(jf,"error is in connection class");
                    return null;
                 }
    
    }
            }
